# CHANGELOG — 总纲更新记录

## V3.6.0 (2026-07-13)

### 新增
- **Phase 门禁引擎**（开发总纲核心机制升级）：每个 Phase 有 gate_file/produce_file，形成不可跳过的执行链。解决 V3.4 中 Phase 5/7/8 和全部检查点被系统性跳过的根因。
- **三IDE角色自动化联通协议_V1.0.md**：定义 Codex/OpenClaw/Cursor 三个 IDE 实例通过共享文件系统异步通信的协议。
- **开发总纲_V3.5_优化方案.md**：V3.5 的 11 项优化执行记录（已执行完毕）。

### 变更
- `开发总纲_人类可读版.md`：新增 Phase 门禁引擎完整章节（门禁链、反跳过机制、单 Agent 自检模式、创作类简化规则）
- `开发总纲_可执行版.json`：V3.5→V3.6，新增 `phase_gate_engine` 章节（约 200 行），含 8 个 Phase 的 gate 定义
- `AGENT_INSTRUCTION.md`：新增"强制开机：Phase 门禁引擎"章节（5 步启动流程、门禁链可视化、反跳过机制）
- `Agent子节点沟通模板.md`：去重处理，与 AGENT_INSTRUCTION.md 职责分离
- `orchestrator.js`：三 IDE 真实分离架构版调度器

### 实测验证
- V3.6 门禁引擎已通过完整运行测试：8 个 Phase 全部执行，8 个自检文件全部写入，9 个管道产物全部就位
